#!/usr/bin/bash

docker exec -it myapache /bin/bash
