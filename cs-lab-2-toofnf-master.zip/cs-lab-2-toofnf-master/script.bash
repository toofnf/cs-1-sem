#!/bin/bash
x=$1
y=$2
let z1=($x * $y)
let z2=($x / $y)
if [[ $y -eq 0 ]]
then
	echo "$(($x + $y)) $(($x - $y)) $(($x * $y)) # "
else
	if [[ $x -eq 0 ]]
	then
		echo "$(($x + $y)) $(($x - $y)) $(($x * $y)) 0.00"
	else
		if [[ $z1 -gt 0 ]]
		then
			if [[ $z2 -ge 1 ]]
			then
				echo "$(($x + $y)) $(($x - $y)) $(($x * $y)) $(bc<<<"scale=2;$x / $y")"
			else
				echo "$(($x + $y)) $(($x - $y)) $(($x * $y)) 0$(bc<<<"scale=2;$x / $y")"
			fi
		else
			if [[ $z2 -le -1 ]]
			then
				echo "$(($x + $y)) $(($x - $y)) $(($x * $y)) $(bc<<<"scale=2;$x / $y")"
			else
				echo "$(($x + $y)) $(($x - $y)) $(($x * $y)) -0$(bc<<<"scale=2; -1 * $x / $y")"
			fi
		fi
	fi
fi
