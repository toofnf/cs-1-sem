#!/bin/bash
for i in $@
do
	ping -c 1 $i &>/dev/null
	if [[ $? = 0 ]];
	then
		echo "HOST IS UP"
	else
		echo "HOST IS DOWN"
	fi
done
