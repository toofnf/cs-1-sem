docker build -t myapache .
