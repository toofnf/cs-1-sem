#!/bin/bash
echo "Welcome, $*"
